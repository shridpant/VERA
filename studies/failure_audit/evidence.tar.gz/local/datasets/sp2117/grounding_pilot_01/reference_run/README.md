Snapshot for WI-01, made 2026-10-24. Read-only copy; nothing in the source folders was changed.
- prompt.txt, metrics.json, status.json, raw_responses.jsonl: from the archived 0.99494 acceptance run
  ~/vera_research/experiments/vera_lab_acceptance/2026-10-24_full_video_RoadAccidents127_x264/pipeline/run 1 (started 19:17:37Z).
- inputs/2240/baseline/*.png and the 8 native frames: from VERA-lab demo_runs/current/pipeline/run 1 (rerun 21:38Z), whose
  162 raw responses are byte-identical to the archived run. The PNG pixel sha256 values match the archived rgb_sha256.
The archive excluded input PNGs; demo_runs/current can be overwritten by the lab session at any time.
