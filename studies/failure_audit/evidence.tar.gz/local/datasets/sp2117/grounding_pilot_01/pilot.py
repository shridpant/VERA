#!/usr/bin/env python3
"""Grounding pilot 01: can frozen InternVL2-8B box its own evidence on one correctly classified VERA alert window?

Read-only on the reference run. Uses the exact 448x448 inputs VERA saw (inputs/<anchor>/baseline/*.png) and its
prompt.txt. Steps: (0) re-run the baseline call and compare with the reference text, (1) ask for evidence claims
+ frame numbers as a follow-up turn, (2) ground each claim on its cited frames (all 8 if none) with the model
card prompt, one frame per call, (3) a control phrase grounded on all 8 frames. Nothing is parsed into a box
unless the raw text contains one; the coordinate scale (believed 0-1000) is an assumption checked by eye on the
saved overlays.
"""
import argparse, json, re, shutil, time
from pathlib import Path
import torch
import torchvision.transforms as T
from torchvision.transforms.functional import InterpolationMode
from PIL import Image, ImageDraw
from transformers import AutoModel, AutoTokenizer

CARD = 'Please provide the bounding box coordinates of the region this sentence describes: <ref>{}</ref>'
CLAIMS = ('The 8 images above are in time order: Frame 1 is the first image and Frame 8 is the last.\n'
          'List the visual evidence for your answer, at most 3 items. Write each item on its own line in exactly this format:\n'
          'Evidence: <short description of one visible object or region> | Frames: <frame numbers from 1 to 8 where it is visible>')
CONTROL = 'the vehicles involved in the accident'
BOX = re.compile(r'\[\[?\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*\]')


def parse_claims(text):
    claims = []
    for line in text.splitlines():
        m = re.match(r'\s*[-*\d.)\s]*Evidence:\s*(.+?)\s*(?:\|\s*Frames?:\s*(.*))?$', line, re.I)
        if not m:
            continue
        frames, raw = [], m.group(2) or ''
        if re.search(r'\ball\b', raw, re.I):
            frames = list(range(1, 9))
        for a, b in re.findall(r'(\d+)\s*(?:-\s*(\d+))?', raw):
            frames += list(range(int(a), int(b or a) + 1))
        frames = sorted({f for f in frames if 1 <= f <= 8})
        claims.append({'claim': m.group(1).strip(), 'cited_frames': frames,
                       'frame_assignment': 'cited' if frames else 'all_frames_by_default'})
    return claims[:3]


def parse_boxes(text, scale):
    boxes = []
    for g in BOX.findall(text):
        x1, y1, x2, y2 = map(float, g)
        ok = 0 <= x1 < x2 <= scale and 0 <= y1 < y2 <= scale
        boxes.append({'norm': [x1 / scale, y1 / scale, x2 / scale, y2 / scale] if ok else None,
                      'raw': [x1, y1, x2, y2], 'status': 'ok' if ok else 'out_of_range_or_degenerate'})
    return boxes


def tag_format(tagged):
    """Which grounding tag family the model emitted; chat() strips both, so read the decode that keeps special tokens."""
    if '<box>' in tagged:
        return 'internvl_ref_box'
    if '<|box_start|>' in tagged:
        return 'qwen_box_start'
    return 'none'


def draw(img, boxes, label):
    im = img.copy(); d = ImageDraw.Draw(im); w, h = im.size
    for b in boxes:
        if b['norm']:
            x1, y1, x2, y2 = b['norm']
            d.rectangle([x1 * w, y1 * h, x2 * w, y2 * h], outline=(255, 0, 0), width=max(2, w // 160))
    d.text((4, 4), label[:60], fill=(255, 255, 0))
    return im


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', required=True, help='reference run folder (contains output/)')
    ap.add_argument('--video', default='RoadAccidents127_x264')
    ap.add_argument('--anchor', type=int, default=2240)
    ap.add_argument('--model', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--scale', type=float, default=1000.0)
    a = ap.parse_args()
    src = Path(a.run) / 'output'; vid = src / a.video; out = Path(a.out); out.mkdir(parents=True)
    ref = next(json.loads(l) for l in (vid / 'raw_responses.jsonl').read_text().splitlines()
               if json.loads(l)['anchor'] == a.anchor)
    assert ref['strict_label'] == 1, 'pilot requires an alert window'
    # Snapshot exactly what is used, since the reference folder may be rewritten later.
    snap = out / 'inputs'; shutil.copytree(vid / 'inputs' / str(a.anchor) / 'baseline', snap)
    shutil.copy(src / 'prompt.txt', out / 'prompt.txt'); (out / 'reference_record.json').write_text(json.dumps(ref, indent=2))
    imgs = [Image.open(snap / f'{i:02d}.png').convert('RGB') for i in range(8)]
    natives = [Image.open(vid / 'frames' / f'{i:06d}.jpg').convert('RGB') for i in ref['frame_indices']]
    question = (out / 'prompt.txt').read_text()

    tok = AutoTokenizer.from_pretrained(a.model, trust_remote_code=True, local_files_only=True)
    model = AutoModel.from_pretrained(a.model, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True, trust_remote_code=True,
                                      use_flash_attn=False, local_files_only=True).eval().cuda()
    # Observation only: keep the generated ids, because chat()/batch_chat() decode with skip_special_tokens=True and
    # drop <ref>/<box> (special tokens 92549-92552). The tagged decode below shows what the model really generated.
    last, generate = {}, model.generate
    def capture(*args, **kwargs):
        result = generate(*args, **kwargs); last['ids'] = result[0].tolist(); return result
    model.generate = capture
    tf = T.Compose([T.Resize((448, 448), interpolation=InterpolationMode.BICUBIC), T.ToTensor(),
                    T.Normalize((.485, .456, .406), (.229, .224, .225))])
    px = lambda ims: torch.stack([tf(i) for i in ims]).to('cuda', torch.bfloat16)
    gen = lambda n: dict(num_beams=1, max_new_tokens=n, do_sample=False)
    log = {'gpu': torch.cuda.get_device_name(0), 'anchor': a.anchor, 'frame_indices': ref['frame_indices'],
           'coordinate_scale_assumed': a.scale, 'calls': []}

    def call(kind, fn, **meta):
        last.clear(); torch.cuda.synchronize(); t = time.time()
        with torch.inference_mode():
            text = fn()
        torch.cuda.synchronize(); seconds = round(time.time() - t, 3)
        ids = last.get('ids', [])
        tagged = tok.decode(ids, skip_special_tokens=False)
        log['calls'].append({'kind': kind, **meta, 'raw_text': text, 'text_with_special_tokens': tagged,
                             'generated_token_ids': ids, 'seconds': seconds})
        print(kind, meta, repr(tagged), flush=True)
        return text

    pv8 = px(imgs)
    base = call('baseline_rerun', lambda: model.batch_chat(tok, pv8, num_patches_list=[8], questions=[question],
                                                         generation_config=gen(512))[0])
    log['baseline_rerun_identical_to_reference'] = base == ref['raw_response']
    claims_text = call('claims', lambda: model.chat(tok, pv8, CLAIMS, gen(256), history=[(question, ref['raw_response'])],
                                                     num_patches_list=[8]))
    claims = parse_claims(claims_text) + [{'claim': CONTROL, 'cited_frames': [], 'frame_assignment': 'control_all_frames'}]
    log['claims'] = claims
    rows = []
    for ci, c in enumerate(claims):
        for slot in (c['cited_frames'] or range(1, 9)):
            # 100 new tokens, as the official RefCOCO eval: the answer echoes the phrase before the box.
            text = call('ground', lambda: model.chat(tok, px([imgs[slot - 1]]), CARD.format(c['claim']), gen(100)),
                        claim_index=ci, frame_slot=slot)
            tagged = log['calls'][-1]['text_with_special_tokens']
            boxes = parse_boxes(text, a.scale)
            rows.append({'claim_index': ci, 'claim': c['claim'], 'frame_assignment': c['frame_assignment'], 'frame_slot': slot,
                         'source_frame_index': ref['frame_indices'][slot - 1], 'raw_text': text,
                         'text_with_special_tokens': tagged, 'tag_format': tag_format(tagged), 'boxes': boxes,
                         'status': 'no_box' if not boxes else ('ok' if all(b['norm'] for b in boxes) else 'malformed')})
            tag = f'claim{ci}_frame{slot}'
            draw(imgs[slot - 1], boxes, c['claim']).save(out / f'overlay448_{tag}.png')
            draw(natives[slot - 1], boxes, c['claim']).save(out / f'overlay_native_{tag}.png')
    log['grounding'] = rows
    log['summary'] = {'claims_parsed': len(claims) - 1, 'grounding_calls': len(rows),
                      'with_box': sum(r['status'] == 'ok' for r in rows),
                      'tag_formats': {f: sum(r['tag_format'] == f for r in rows) for f in sorted({r['tag_format'] for r in rows})},
                      'grounding_seconds_total': round(sum(c['seconds'] for c in log['calls'] if c['kind'] == 'ground'), 2),
                      'peak_gpu_mem_gib': round(torch.cuda.max_memory_allocated() / 2**30, 2)}
    (out / 'pilot_result.json').write_text(json.dumps(log, indent=2, ensure_ascii=False))
    print(json.dumps(log['summary']), flush=True)


if __name__ == '__main__':
    main()
